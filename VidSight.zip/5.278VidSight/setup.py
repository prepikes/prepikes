import logging
from moviepy.editor import VideoFileClip
from faster_whisper import WhisperModel
import time
import os
import argparse
import sys
print(sys.executable)
# 配置日志记录
log_format = "%(asctime)s - %(levelname)s - %(message)s"
logging.basicConfig(filename='my_script.log', level=logging.INFO, format=log_format)

# 设置环境变量
os.environ["KMP_DUPLICATE_LIB_OK"] = "TRUE"
model_size = "small1"
model = WhisperModel(model_size, device="cpu", compute_type="int8")
def video_to_audio(video_path, audio_path):
    video = VideoFileClip(video_path)
    audio = video.audio
    audio.write_audiofile(audio_path)
    video.close()
    audio.close()
def transcribe_audio(audio_path, output_text_file):
    model_size = "small1"
    model = WhisperModel(model_size, device="cpu", compute_type="int8")
    s = time.time()
    segments, info = model.transcribe(audio_path, beam_size=5)
    with open(output_text_file, 'w', encoding='utf-8') as file:
        for segment in segments:
            line = "[%.2fs->%.2fs] %s\n" % (segment.start, segment.end, segment.text)
            print(line, end='')  # 在后端打印出来，方便调试
            file.write(line)
    print("Total transcription time: {:.2f}s".format(time.time() - s))

# 解析命令行参数
parser = argparse.ArgumentParser(description='Process an integer value.')
parser.add_argument('value', type=int, help='An integer value to process')
args = parser.parse_args()
video_path = './myapp/user_files/' + str(args.value) + '/1.mp4'
audio_path = './myapp/user_files/' + str(args.value) + '/1.mp3'
output_text_file = './myapp/user_files/' + str(args.value) + '/1.txt'

video_to_audio(video_path, audio_path)
transcribe_audio(audio_path, output_text_file)

# 新增代码，读取文本文件内容并返回
try:
    with open(output_text_file, 'r', encoding='utf-8') as file:
        transcription_text = file.read()
        print("Transcription output:\n", transcription_text)  # 打印生成的文本文件内容，方便调试
        logging.info("Read transcription text from file successfully")
except Exception as e:
    logging.error(f"Error reading transcription text from file: {str(e)}")
