from celery import shared_task
import subprocess
import logging
logger = logging.getLogger(__name__)
@shared_task
def long_running_task(a):
    result = subprocess.run(
        ['python', './objdt.py', str(a)],
        capture_output=True,
        text=True
    )
    logging.info("Standard Output: %s", result.stdout)
    logging.error("Standard Error: %s", result.stderr)
    logging.info("Return Code: %d", result.returncode)