"""myproject URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path, include
from django.views.generic import RedirectView
from myapp import views
from myapp.views import run_script

urlpatterns = [
    #path('', views.static_page, name='demo'),  # 根路径指向 demo 页面
    path('index/', views.index),
path('admin/', admin.site.urls),
path('', RedirectView.as_view(url='/users/login/', permanent=True)),  # 根 URL 重定向到登录页面
#path('', views.static_page,name='login'),  # 根 URL 重定向到登录页面
path('', views.demo, name='demo'),  # 定义主页的 URL 路由，并命名为 'demo'
   path('users/', include('myapp.urls')),
path('getpicturetext/', views.getpicturetext, name='getpicturetext'),
    path('upload-video/', views.upload_view, name='upload-video'),
    path('get-text-from-file/', views.get_text_from_file, name='get-text-from-file'),
path('get-text-from-file1/', views.get_text_from_file1, name='get-text-from-file1'),
    path('runscript/', run_script, name='run_script'),
    path('summarize-text/', views.summarize_text, name='summarize_text'),
]
