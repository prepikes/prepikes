from __future__ import absolute_import, unicode_literals
import os
from celery import Celery

# 设置默认的 Django settings 模块，用于 Celery 应用
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'your_project.settings')

# 创建 Celery 实例
app = Celery('your_project')

# 使用 Django settings.py 中的配置
app.config_from_object('django.conf:settings', namespace='CELERY')

# 从所有注册的 Django app 中加载任务模块
app.autodiscover_tasks()