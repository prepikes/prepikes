from django.urls import path
from .views import user_login,demo,register

urlpatterns = [
    path('login/', user_login, name='login'),
path('demo/', demo, name='demo'),  # 主页的 URL 路由
path('register/', register, name='register'),  # 添加注册页面的 URL 路由
]