import logging
from myproject.tasks import long_running_task
from django.shortcuts import render,HttpResponse,redirect
from django.http import JsonResponse
import json
from django.contrib.auth import authenticate, login
from django.contrib.auth.forms import AuthenticationForm
from asgiref.sync import sync_to_async
from django.contrib.auth.forms import AuthenticationForm, UserCreationForm
import subprocess
import os
import requests
from django.views.decorators.csrf import csrf_exempt
from django.db.models.signals import post_save
from django.dispatch import receiver
from django.contrib.auth.models import User
from django.urls import reverse
import sys

logger = logging.getLogger(__name__)
# Create your views here.
def demo(request):
    return render(request, 'demo.html')
def index(request):
    return HttpResponse("欢迎使用")
def static_page(request):
    return render(request, 'demo.html')
def upgrade(request):
    if request.method == 'POST':
        # 处理按钮点击事件
        return HttpResponse("Button was pressed")
    return render(request, 'home.html')

def upload_view(request):
    if request.method == 'POST':
        user_id = -1
        try:
            logger.debug("This is a debug message")
            user_instance = request.user
            user_id = user_instance.id # 对用户实例进行进一步处理
            logging.debug("User ID: %s", user_id)
        except User.DoesNotExist:
            a=0
        video_file = request.FILES.get('videoFile')
        if video_file and user_id != -1:
            handle_uploaded_file(video_file, user_id)
            return JsonResponse({'message': 'File uploaded successfully!'}, status=200)
        else:
            return JsonResponse({'message': 'No file uploaded'}, status=400)
def handle_uploaded_file(f,user_id):
    save_path = './myapp/user_files/' + str(user_id) + '/'
    if not os.path.exists(save_path):
        os.makedirs(save_path)
    file_path = os.path.join(save_path, '1.mp4')
    
    with open(file_path, 'wb+') as destination:
        for chunk in f.chunks():
            destination.write(chunk)

def get_text_from_file(request):
    user_instance = request.user
    user_id = user_instance.id  # 对用户实例进行进一步处理

    file_path = './myapp/user_files/' + str(user_id) + '/1.txt'  # 替换为你的文本文件路径
    try:
        with open(file_path, 'r', encoding='utf-8') as file:
            text = file.read()  # 读取文本文件内容
        response_data = {'text': text}
        return JsonResponse(response_data)
    except FileNotFoundError:
        return JsonResponse({'error': 'File not found'}, status=404)

def run_script(request):
    if request.method == 'POST':
        user_instance = request.user
        user_id = user_instance.id  # 对用户实例进行进一步处理
        logger.debug(user_id)
        logger.debug("xunihuanjing"+sys.executable)
        # 这里调用你的 Python 脚本
        result = subprocess.run(
            ['python', 'setup.py', str(user_id)],
            capture_output=True,
            text=True
        )
        logging.info("Standard Output: %s", result.stdout)
        logging.error("Standard Error: %s", result.stderr)
        logging.info("Return Code: %d", result.returncode)
        logger.debug("yes2")
        return JsonResponse({'status': 'success', 'output': result.stdout})
    else:
        return JsonResponse({'status': 'error', 'message': 'Invalid request'}, status=400)
    

def get_access_token(api_key, secret_key):
    """
    使用百度云的API Key和Secret Key获取access_token。
    """
    token_url = "https://aip.baidubce.com/oauth/2.0/token"
    params = {
        'grant_type': 'client_credentials',
        'client_id': api_key,
        'client_secret': secret_key
    }
    response = requests.get(token_url, params=params)
    if response.status_code == 200:
        return response.json().get('access_token', None)
    return None

@csrf_exempt
def summarize_text(request):
    if request.method == 'POST':
        user_instance = request.user
        user_id = user_instance.id  # 对用户实例进行进一步处理
        # 读取已经生成的1.txt文件
        try:
            with open('./myapp/user_files/' + str(user_id) + '/1.txt' , 'r', encoding='utf-8') as file:
                transcription_text = file.read()
        except FileNotFoundError:
            return JsonResponse({'error': 'File not found'}, status=404)

        # 获取access_token
        api_key = 't5hdvVHyc3UwYr4wzFHS9Wj3'
        secret_key = 'WMVnM1IKlOj6TDzkH9Ijzn6oKdR5gmUl'
        access_token = get_access_token(api_key, secret_key)
        if not access_token:
            return JsonResponse({'error': 'Failed to retrieve access token'}, status=500)

        # 调用百度千帆API，使用 transcription_text 作为输入
        api_url = 'https://aip.baidubce.com/rpc/2.0/ai_custom/v1/wenxinworkshop/chat/completions'
        headers = {'Content-Type': 'application/json'}
        params = {'access_token': access_token}
        payload = {
            "messages": [
                {"role": "user", "content": transcription_text}
            ]
        }
        response = requests.post(api_url, headers=headers, params=params, json=payload)
        if response.status_code == 200:
            result = response.json()
            return JsonResponse({'summary': result.get('result', 'No summary generated')})
        else:
            return JsonResponse({'error': 'Error in API call: ' + response.text}, status=response.status_code)

    return JsonResponse({'error': 'Invalid request'}, status=400)
def user_login(request):
    if request.method == 'POST':
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')
            user = authenticate(username=username, password=password)
            if user is not None:
                login(request, user)
                return redirect('demo')  # 登录后重定向到主页
    else:
        form = AuthenticationForm()
    return render(request, 'users/login.html', {'form': form})
def register(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            form.save()
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password1')
            user = authenticate(username=username, password=password)
            if user is not None:
                login(request, user)
                return redirect(reverse('login'))  # 这里需要替换为注册成功后要跳转的页面的名称或路径
    else:
        form = UserCreationForm()
    return render(request, 'register.html', {'form': form})
@receiver(post_save, sender=User)
def create_user_directory(sender, instance, created, **kwargs):
    if created:
        user_directory = os.path.join(os.path.dirname(__file__), 'user_files', str(instance.id))
        if not os.path.exists(user_directory):
            os.makedirs(user_directory, exist_ok=True)
def getpicturetext(request):
    if request.method == 'POST':
        data = json.loads(request.body.decode('utf-8'))  # 解析JSON数据
        text_input = data.get('text')  # 获取"text"字段的值
        logging.debug("Text input received: %s", text_input)  # 在这里添加日志记录
        COCO_CLASSES = {
            1: 'person', 2: 'bicycle', 3: 'car', 4: 'motorcycle', 5: 'airplane',
            6: 'bus', 7: 'train', 8: 'truck', 9: 'boat', 10: 'traffic light',
            11: 'fire hydrant', 13: 'stop sign', 14: 'parking meter', 15: 'bench',
            16: 'bird', 17: 'cat', 18: 'dog', 19: 'horse', 20: 'sheep',
            21: 'cow', 22: 'elephant', 23: 'bear', 24: 'zebra', 25: 'giraffe',
            27: 'backpack', 28: 'umbrella', 31: 'handbag', 32: 'tie', 33: 'suitcase',
            34: 'frisbee', 35: 'skis', 36: 'snowboard', 37: 'sports ball', 38: 'kite',
            39: 'baseball bat', 40: 'baseball glove', 41: 'skateboard', 42: 'surfboard',
            43: 'tennis racket', 44: 'bottle', 46: 'wine glass', 47: 'cup', 48: 'fork',
            49: 'knife', 50: 'spoon', 51: 'bowl', 52: 'banana', 53: 'apple',
            54: 'sandwich', 55: 'orange', 56: 'broccoli', 57: 'carrot', 58: 'hot dog',
            59: 'pizza', 60: 'donut', 61: 'cake', 62: 'chair', 63: 'couch',
            64: 'potted plant', 65: 'bed', 67: 'dining table', 70: 'toilet', 72: 'tv',
            73: 'laptop', 74: 'mouse', 75: 'remote', 76: 'keyboard', 77: 'cell phone',
            78: 'microwave', 79: 'oven', 80: 'toaster', 81: 'sink', 82: 'refrigerator',
            84: 'book', 85: 'clock', 86: 'vase', 87: 'scissors', 88: 'teddy bear',
            89: 'hair drier', 90: 'toothbrush'}
        for value in COCO_CLASSES.values():
            if text_input.lower() == value:
                a=True
                break
            else:
                a=False
        if a:
            user_instance = request.user
            user_id = user_instance.id  # 对用户实例进行进一步处理
            long_running_task(user_id)
            return JsonResponse({'message': 'No textded'})
        else:
            return JsonResponse({'message': 'No text uploaded'}, status=400)

def get_text_from_file1(request):
    user_instance = request.user
    user_id = user_instance.id  # 对用户实例进行进一步处理
    file_path = './myapp/user_files/' + str(user_id) + '/2.txt'  # 替换为你的文本文件路径
    try:
        with open(file_path, 'r', encoding='utf-8') as file:
            text = file.read()  # 读取文本文件内容
            logger.debug(f'Read text: {text}')  # 记录读取的内容
        response_data = {'text': text}
        return JsonResponse(response_data)
    except FileNotFoundError:
        return JsonResponse({'message': 'No text uploaded'}, status=400)


